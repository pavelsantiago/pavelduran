 ----------------------------------------------------------------------------------------------------------
This exclusive resource has been copyrighted and owned by QooQee LLC / qooqee.com 
----------------------------------------------------------------------------------------------------------


ULTIMATE PASS USERS TERMS OF USE:


Please read the following terms and conditions carefully


Do not Resell our templates or widgets online in any format.
Do not Distribute our templates, widgets  or assets without permission.
When you 'purchase' a template   or widget from QooQee.com, you're actually purchasing a license to use that template.
Our License allows use of the template  or widget in one single end product which end users are not charged to access or use. You can do this directly or, if you're a freelancer, you can create the end product for one client to distribute free to its end users. You can charge your client to produce the single end product. Distribution of source files is not permitted.
This license is a “single application” license and not a “multi-use” license, which means that you can’t use the Item to create more than one unique End Product.
You can’t re-distribute the Item as stock, in a tool, template  or widget, or with source files. You can’t do this with an Item either on its own or bundled with other items, and even if you modify the Item. You can’t re-distribute or make available the Item as-is or with superficial modifications.
Although you can modify the Item and therefore delete components before creating your single End Product, you can’t extract and use a single component of an Item on a stand-alone basis.
You must not permit an end user of the End Product to extract the Item and use it separately from the End Product.
 
 
 

Cheers,
QooQee LCC
QooQee.com
_________________________
website: www.qooqee.com
email: info@qooqee.com
http://www.qooqee.com/terms-condition